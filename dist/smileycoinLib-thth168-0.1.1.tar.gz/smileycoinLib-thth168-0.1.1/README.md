# SmileyLib

This is a simple pip package for communicating with the smiley deamon.

## Requirements

Smileycoind has to be set up locally for this to run